# Theatre wishlist rescue

Аварийно восстановленная версия. Данные загружаются из Supabase.
